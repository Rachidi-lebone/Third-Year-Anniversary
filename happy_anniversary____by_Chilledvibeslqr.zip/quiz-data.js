export const quizData = [
    {
        question: "Where did we have our first official date?",
        options: ["Chicken Licken parking lot", "Maboneng Night Market", "Fourways Farmers Market", "Rosebank Mall food court"],
        correct: 2
    },
    {
        question: "What did the message I typed in your notes at Sibu’s birthday party say?",
        options: ["You’re my favorite human.", "You are exactly who I want.", "You’re my person.", "I choose you, always."],
        correct: 1
    },
    {
        question: "What message was written on the first plant I gave to you?",
        options: ["My sunshine", "Grow with me", "Forever us", "Love"],
        correct: 3
    },
    {
        question: "Who was the first to say “I love you”?",
        options: ["Fleshling", "Happy Feet", "Both at the same time", "Texted later that night"],
        correct: 0
    },
    {
        question: "Where did we first do the naughty deed?",
        options: ["My house in Roodekop", "Her house in Leondale", "Her car", "A BnB"],
        correct: 1
    },
    {
        question: "What is our song?",
        options: ["Michael Jackson — Heaven Can Wait", "Alicia Keys — If I Ain’t Got You", "Wizkid — Essence", "Tems — Found"],
        correct: 3
    },
    {
        question: "Complete the sentence: “I love you…”",
        options: ["3000", "a lot, a lot", "aggressively", "forever"],
        correct: 0
    },
    {
        question: "What movie did the line “I love you 3000” come from?",
        options: ["Avengers: Infinity War", "Avengers: Endgame", "Transformers", "Twilight"],
        correct: 1
    },
    {
        question: "What is the worst gift I have gotten you so far?",
        options: ["This very game", "The projector", "My suit watch", "A plant"],
        correct: 2
    },
    {
        question: "What were the words I used to ask you to become an official couple?",
        options: ["Can I be your boyfriend?", "Can you be my girlfriend?", "Will you go out with me?", "Can we be exclusive?"],
        correct: 0
    }
];